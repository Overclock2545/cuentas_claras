import 'package:cloud_firestore/cloud_firestore.dart';

/// Representa cuánto le corresponde pagar a UN participante de UN gasto
/// específico. Se calcula y se guarda ya resuelto en pesos/soles (no en
/// porcentajes) para que el cálculo de deudas (Flujo 5) sea un simple sumar,
/// sin importar si el gasto se dividió en partes iguales, por porcentaje o
/// con montos exactos.
class ExpenseSplitModel {
  final String participantId;
  final String participantName;
  final double amount;

  const ExpenseSplitModel({
    required this.participantId,
    required this.participantName,
    required this.amount,
  });

  Map<String, dynamic> toMap() {
    return {
      'participantId': participantId,
      'participantName': participantName,
      'amount': amount,
    };
  }

  factory ExpenseSplitModel.fromMap(Map<String, dynamic> map) {
    final amount = map['amount'];
    return ExpenseSplitModel(
      participantId: map['participantId'] ?? '',
      participantName: map['participantName'] ?? '',
      amount: amount is num ? amount.toDouble() : 0,
    );
  }
}

/// Cómo se repartió el gasto entre los participantes seleccionados.
enum ExpenseSplitType { equal, percentage, fixed }

extension ExpenseSplitTypeX on ExpenseSplitType {
  String get value => switch (this) {
        ExpenseSplitType.equal => 'equal',
        ExpenseSplitType.percentage => 'percentage',
        ExpenseSplitType.fixed => 'fixed',
      };

  static ExpenseSplitType fromValue(String? value) => switch (value) {
        'percentage' => ExpenseSplitType.percentage,
        'fixed' => ExpenseSplitType.fixed,
        _ => ExpenseSplitType.equal,
      };
}

class ExpenseModel {
  final String id;
  final String eventId;
  final String title;
  final double amount;
  final String paidById; // UID del usuario que pagó
  final String
      paidByName; // Nombre del usuario que pagó (para ahorrar lecturas)
  final DateTime createdAt;
  final ExpenseSplitType splitType;
  final List<ExpenseSplitModel> splits;

  ExpenseModel({
    required this.id,
    required this.eventId,
    required this.title,
    required this.amount,
    required this.paidById,
    required this.paidByName,
    required this.createdAt,
    this.splitType = ExpenseSplitType.equal,
    this.splits = const [],
  });

  // Convertir a Mapa para guardar en Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'eventId': eventId,
      'title': title,
      'amount': amount,
      'paidById': paidById,
      'paidByName': paidByName,
      'createdAt': Timestamp.fromDate(createdAt),
      'splitType': splitType.value,
      'splits': splits.map((s) => s.toMap()).toList(),
    };
  }

  // Crear instancia desde Firestore
  factory ExpenseModel.fromMap(Map<String, dynamic> map) {
    final amount = map['amount'];
    final createdAt = map['createdAt'];
    final rawSplits = map['splits'];
    return ExpenseModel(
      id: map['id'] ?? '',
      eventId: map['eventId'] ?? '',
      title: map['title'] ?? '',
      amount: amount is num ? amount.toDouble() : 0,
      paidById: map['paidById'] ?? '',
      paidByName: map['paidByName'] ?? '',
      createdAt: createdAt is Timestamp ? createdAt.toDate() : DateTime.now(),
      splitType: ExpenseSplitTypeX.fromValue(map['splitType'] as String?),
      splits: rawSplits is List
          ? rawSplits
              .whereType<Map<String, dynamic>>()
              .map(ExpenseSplitModel.fromMap)
              .toList()
          : const [],
    );
  }
}
